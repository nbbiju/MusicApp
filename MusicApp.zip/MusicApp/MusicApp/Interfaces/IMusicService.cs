﻿using MusicApp.ViewModels;

namespace MusicApp.Interfaces
{
    public interface IMusicService
    {

       Task<List<Song>?> GetSongsByArtistAsync(string ArtistName);
    }
}
