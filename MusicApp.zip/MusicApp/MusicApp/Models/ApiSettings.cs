﻿namespace MusicApp.Models
{
    public class ApiSettings
    {
        public string BaseUrl { get; set; } = string.Empty;
        public string GetArtistMbIdUrl { get; set; } = string.Empty;
        public string GetRecordsByArtistUrl { get; set; } = string.Empty;
        public string GetAlbumsByRecordUrl { get; set; } = string.Empty;
        //public Endpoints Endpoints { get; set; }
    }

    //public class Endpoints
    //{
    //    public string GetUser { get; set; }
    //    public string GetOrders { get; set; }
    //}

}
