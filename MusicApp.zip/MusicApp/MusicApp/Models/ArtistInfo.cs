﻿using System;

namespace MusicApp.Models
{
    public class ArtistInfo
    {
        public List<Artist> artists { get; set; }
    }
    public class Artist
    {
        public string id { get; set; }
        public string name { get; set; }
    }
    // 
}
