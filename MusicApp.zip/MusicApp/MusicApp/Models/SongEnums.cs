﻿namespace MusicApp.Models
{
    public enum SongEnums
    {
        album
    }
}
