﻿
using System.Text.Json.Serialization;

namespace MusicApp.Models
{
    public class AlbumInfo
    {
        public string RecordMbId { get; set; } = string.Empty;
        public List<Release>? releases { get; set; } 
    }
    public class Release
    {

        [JsonPropertyName("release-group")]
        public ReleaseGroup? releasegroup { get; set; }
        public string title { get; set; } = string.Empty;
    }

    public class ReleaseGroup
    {

        [JsonPropertyName("primary-type")]
        public string primarytype { get; set; }= string.Empty;

        public string title { get; set; } = string.Empty;
    }
}