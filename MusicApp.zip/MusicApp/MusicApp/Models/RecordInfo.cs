﻿namespace MusicApp.Models
{
    public class RecordInfo
    {
        public List<Recording> recordings { get; set; }
    }
}

// Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
public class Recording
{
    public string title { get; set; }
    public string id { get; set; }
}



