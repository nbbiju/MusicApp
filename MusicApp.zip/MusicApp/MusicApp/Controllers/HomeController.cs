using Microsoft.AspNetCore.Mvc;
using MusicApp.Interfaces;
using MusicApp.Models;
using MusicApp.ViewModels;
using System.Diagnostics;

namespace MusicApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMusicService _musicService;
        public HomeController(IMusicService musicService, ILogger<HomeController> logger)
        {
            _logger = logger;
            _musicService = musicService;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        [ResponseCache(Duration = 60, VaryByQueryKeys = new[] { "ArtistName" }, Location = ResponseCacheLocation.Any)]
        public async Task<JsonResult> Search(string ArtistName)
        {
            try
            {
                List<Song>? songs = new List<Song>();
                
                if (string.IsNullOrEmpty(ArtistName))
                {
                    return Json(songs);
                }
                songs = await _musicService.GetSongsByArtistAsync(ArtistName);
                return Json(songs);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        
    }
}
