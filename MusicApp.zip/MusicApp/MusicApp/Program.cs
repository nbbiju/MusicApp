using Microsoft.Extensions.Configuration;
using MusicApp.Interfaces;
using MusicApp.Models;
using MusicApp.Services;


var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient();
builder.Services.AddHttpClient("MyApiClient", client =>
{
    client.DefaultRequestHeaders.Add("Accept", "application/json");
    client.DefaultRequestHeaders.UserAgent.ParseAdd("MusicApp/1.0 ( nbbiju@gmail.com )");
});

builder.Services.AddScoped<IMusicService, MusicService>();
builder.Services.Configure<ApiSettings>(builder.Configuration.GetSection("ApiSettings"));
// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseResponseCaching();   
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
