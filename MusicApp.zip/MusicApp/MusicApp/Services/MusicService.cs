﻿using Microsoft.Extensions.Options;
using MusicApp.Controllers;
using MusicApp.Interfaces;
using MusicApp.Models;
using MusicApp.ViewModels;
using System.Net;
using System.Text.Json;

namespace MusicApp.Services
{
    public class MusicService: IMusicService
    { 
        private readonly HttpClient _httpClient;
        private readonly ApiSettings _apiSettings;
        private readonly ILogger<MusicService> _logger;
        public MusicService(IHttpClientFactory httpClientFactory, IOptions<ApiSettings> apiSettings, ILogger<MusicService> logger) 
        { 
            _httpClient = httpClientFactory.CreateClient("MyApiClient");
            _apiSettings = apiSettings.Value;
            _logger = logger;
        }
        public async Task<List<Song>?> GetSongsByArtistAsync(string ArtistName) 
        {
            try
            {
                var songs = new List<Song>();

                RecordInfo? recordDetails = null;
                string? artistMbId = string.Empty;

                artistMbId = await GetArtist(ArtistName);
                if (!string.IsNullOrEmpty(artistMbId))
                {
                    recordDetails = await GetRecords(artistMbId);
                    
                    if(recordDetails != null && recordDetails.recordings.Count != 0)
                    {
                        AddRecordsToResult(recordDetails, songs);

                        List<AlbumInfo> albums = await GetAlbums(recordDetails);
                        if(albums != null && albums.Count > 0)
                        {
                            AddAlbumsToResult(albums, songs);
                        }
                    }
                }
                
                return songs;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        private async Task<string?> GetArtist(string ArtistName)
        {
            try
            {
                string? ArtistMbId = string.Empty;

                var getArtistMbIdUrl = string.Format(_apiSettings.GetArtistMbIdUrl, ArtistName);
                
                HttpResponseMessage response = await _httpClient.GetAsync(getArtistMbIdUrl);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    ArtistInfo? ArtistDetails = null;

                    if (!string.IsNullOrEmpty(jsonResponse))
                    {
                        ArtistDetails = JsonSerializer.Deserialize<ArtistInfo>(jsonResponse);
                        ArtistMbId = GetArtistMbId(ArtistDetails, ArtistName);
                    }
                }
                
                return ArtistMbId;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        private string? GetArtistMbId(ArtistInfo? ArtistDetails,string ArtistName)
        {
            try
            {
                string? artistMbId = string.Empty;
                if(ArtistDetails != null)
                {
                    artistMbId = ArtistDetails.artists.Where(x => x.name.ToLower() == ArtistName.ToLower()).Select(y => y.id).FirstOrDefault();
                }
                return artistMbId ?? "";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);

                throw;
            }
        }
        private async Task<RecordInfo?> GetRecords(string? ArtistMbId)
        {
            try
            {
                RecordInfo? RecordDetails = null;

                var getRecordsByArtistUrl = string.Format(_apiSettings.GetRecordsByArtistUrl, ArtistMbId);

                HttpResponseMessage response = await _httpClient.GetAsync(getRecordsByArtistUrl);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                
                    if (!string.IsNullOrEmpty(jsonResponse))
                    {
                        RecordDetails = JsonSerializer.Deserialize<RecordInfo>(jsonResponse);
                    }
                    
                }

                return RecordDetails;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        private void AddRecordsToResult(RecordInfo RecordDetails, List<Song> Songs)
        {
            try
            {
                foreach(var record in RecordDetails.recordings)
                {
                    Songs.Add(new Song { Title = record.title, RecordMbId = record.id });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        private async Task<List<AlbumInfo>> GetAlbums(RecordInfo? RecordDetails)
        {
            try
            {
                List<AlbumInfo> albums = new List<AlbumInfo>();
                AlbumInfo? albumDetails = null;

                if (RecordDetails != null && RecordDetails.recordings.Count > 0)
                {
                    var getAlbumsByRecordUrl = _apiSettings.GetAlbumsByRecordUrl;

                    var tasks = new List<Task<HttpResponseMessage>>();
                    foreach(var recording in RecordDetails.recordings)
                    {
                        tasks.Add(_httpClient.GetAsync(string.Format(_apiSettings.GetAlbumsByRecordUrl, recording.id)));
                    }
                    var responses = await Task.WhenAll(tasks);
                    string jsonResponse = string.Empty;

                    var absoluteUri = string.Empty;
                    foreach (var response in responses)
                    {
                        jsonResponse = await response.Content.ReadAsStringAsync();
                        albumDetails = JsonSerializer.Deserialize<AlbumInfo>(jsonResponse);
                        if(albumDetails != null)
                        {
                            foreach (var recording in RecordDetails.recordings)
                            {
                                absoluteUri = response?.RequestMessage?.RequestUri?.AbsoluteUri;
                                if (!string.IsNullOrEmpty(absoluteUri) && absoluteUri.Contains(recording.id))
                                {
                                    albumDetails.RecordMbId = recording.id;
                                    albums.Add(albumDetails);
                                }
                            }
                        }
                        
                    }
                }
                return albums;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
        private void AddAlbumsToResult(List<AlbumInfo> Albums, List<Song> Songs)
        {
            try
            {
                var recordMbId = string.Empty;
                List<string>? result = null;
                foreach (var album in Albums)
                {
                    recordMbId = album.RecordMbId;
                    result = album?.releases?.Where(x => x.releasegroup?.primarytype.ToLower() == SongEnums.album.ToString()).
                        Select(x=>x.title).ToList();
                    if(result != null && result.Count > 0)
                    {
                        foreach (var song in Songs)
                        {
                            if (song.RecordMbId == recordMbId)
                            {
                                song.Albums = string.Join(", ", result);
                            }
                        }
                    }
                    

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
    }
}


