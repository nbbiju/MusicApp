﻿namespace MusicApp.ViewModels
{
    public class Song
    {
        public string Title { get; set; } = string.Empty;
        public string RecordMbId { get; set; } = string.Empty;
        public string Albums { get; set; } = string.Empty;
    }
}
