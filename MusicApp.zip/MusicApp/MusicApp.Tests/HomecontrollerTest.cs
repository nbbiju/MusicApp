using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using MusicApp.Controllers;
using MusicApp.Interfaces;
using MusicApp.ViewModels;

namespace MusicApp.Tests
{
    public class HomecontrollerTest
    {
        [Fact]
        public void YourActionMethod_Returns_JsonResult_With_Expected_Data()
        {
            var str = string.Empty;
            // Arrange
            //var mockLogger = new Mock<ILogger<HomeController>>();
            //var mockService = new Mock<IMusicService>(); // Assuming you have an IYourService interface

            //// Setup the mock service to return some expected data
            ////var expectedData = new Dictionary<string, object>
            ////{
            ////    { "key", "expected value" }
            ////};
            //List<Song>? expectedData = new List<Song> { new Song { Title="", Albums="" }, 
            //};

            //mockService.Setup(service => service.GetSongsByArtistAsync("")).ReturnsAsync(expectedData);

            //var controller = new HomeController(mockService.Object, mockLogger.Object);

            //// Act
            //var result = controller.Search("the beatles")?.Result as JsonResult;

            //// Assert
            //Assert.NotNull(result);
            //var jsonResult = Assert.IsType<JsonResult>(result);
            //Assert.IsType<List<Song>?>(jsonResult.Value);

            //var data = jsonResult.Value as List<Song>;
            //Assert.Equal("expected value", "expected value"); // Replace with actual key and expected value
        }
    }
}